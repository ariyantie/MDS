<?php

use Illuminate\Support\Facades\Route;

Route::post('/login', 'API\AuthController@login');
Route::middleware('auth:sanctum')->group(function () {
    Route::post('/profile/update', 'API\UserController@update');
    Route::post('/loan/apply', 'API\LoanController@apply');
    Route::get('/loan/status', 'API\LoanController@status');
    Route::post('/permission/submit', 'API\PermissionController@submit');
});